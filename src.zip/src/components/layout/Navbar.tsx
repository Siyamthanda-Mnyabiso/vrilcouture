// src/components/layout/Navbar.tsx

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, ShoppingBag, Menu, ChevronDown } from 'lucide-react';
import { useCart } from '../../hooks/useCart';
import { useCategories } from '../../hooks/useCategories';
import { AccountDropdown } from './AccountDropdown';
import { MobileNav } from './MobileNav';


const navigation = [
    {
        title: "MEN",
        items: [
            "T Shirts",
            "Hoodies & Sweaters",
            "Shirts",
            "Jackets",
            "Bottoms",
        ]
    },
    {
        title: "WOMEN",
        items: [
            "Dresses",
            "Tops",
            "Sweaters & Knits",
            "Jackets",
            "Bottoms",
        ]
    },
    {
        title: "ACCESSORIES",
        items: [
            "Caps",
            "Socks",
            "Tote Bags",
            "Gift Cards",
        ]
    },
    {
        title: "UNISEX",
        items: []
    }
];


export function Navbar() {

    const { itemCount } = useCart();

    const { categories, fetchCategories } = useCategories();

    const [mobileNavOpen, setMobileNavOpen] = useState(false);
    const [shopOpen, setShopOpen] = useState(false);


    useEffect(() => {
        fetchCategories();
    }, []);



    return (
        <>
            <nav className="flex items-center justify-between px-4 py-4 sm:px-6 md:px-10 lg:px-14 bg-white">


                {/* LEFT */}
                <div className="flex items-center gap-3">

                    <button
                        className="md:hidden"
                        onClick={() => setMobileNavOpen(true)}
                    >
                        <Menu className="w-6 h-6"/>
                    </button>


                    <Link
                        to="/"
                        className="
                        font-display
                        text-sm
                        sm:text-base
                        font-black
                        uppercase
                        tracking-tight
                        "
                    >
                        Vril<br/>Couture.
                    </Link>

                </div>




                {/* CENTER */}
                <div className="hidden md:flex items-center gap-8">


                    <Link
                        to="/"
                        className="text-sm hover:opacity-50"
                    >
                        Home
                    </Link>


                    <Link
                        to="/about"
                        className="text-sm hover:opacity-50"
                    >
                        About
                    </Link>




                    {/* SHOP */}
                    <div
                        className="relative"
                        onMouseEnter={()=>setShopOpen(true)}
                        onMouseLeave={()=>setShopOpen(false)}
                    >


                        <button className="
                            flex items-center gap-2
                            text-sm
                            uppercase
                            tracking-widest
                        ">
                            Shop

                            <ChevronDown
                                className={`
                                w-4 h-4 transition
                                ${shopOpen ? "rotate-180":""}
                                `}
                            />

                        </button>



                        {shopOpen && (

                            <div
                                className="
                            absolute
                            left-1/2
                            -translate-x-1/2
                            top-full
                            pt-8
                            z-50
                            "
                            >


                                <div
                                    className="
                                w-[1000px]
                                rounded-3xl
                                bg-white
                                border
                                shadow-2xl
                                overflow-hidden
                                "
                                >


                                    <div className="
                                    grid
                                    grid-cols-4
                                    gap-10
                                    p-12
                                    ">



                                        {navigation.map(section=>(


                                            <div key={section.title}>


                                                <h3
                                                    className="
                                            text-xs
                                            tracking-[0.3em]
                                            font-bold
                                            mb-6
                                            "
                                                >
                                                    {section.title}
                                                </h3>



                                                {section.items.length > 0 ? (

                                                    section.items.map(item=>(

                                                        <Link
                                                            key={item}
                                                            to={`/category/${item.toLowerCase().replaceAll(" ","-")}`}
                                                            className="
                                                    block
                                                    text-sm
                                                    mb-4
                                                    hover:translate-x-2
                                                    transition
                                                    "
                                                        >

                                                            {item}

                                                        </Link>

                                                    ))

                                                ):(


                                                    <Link
                                                        to="/shop"
                                                        className="
                                                text-sm
                                                hover:opacity-50
                                                "
                                                    >
                                                        SHOP ALL
                                                    </Link>

                                                )}



                                            </div>

                                        ))}



                                        {/* DATABASE CATEGORIES */}

                                        <div>

                                            <h3
                                                className="
                                        text-xs
                                        tracking-[0.3em]
                                        font-bold
                                        mb-6
                                        "
                                            >
                                                COLLECTIONS
                                            </h3>



                                            {categories.slice(0,5).map(cat=>(

                                                <Link
                                                    key={cat.id}
                                                    to={`/category/${cat.slug}`}
                                                    className="
                                            block
                                            text-sm
                                            mb-4
                                            hover:translate-x-2
                                            transition
                                            "
                                                >
                                                    {cat.name}
                                                </Link>

                                            ))}


                                        </div>



                                    </div>




                                    {/* BOTTOM */}
                                    <div
                                        className="
                                    border-t
                                    px-12
                                    py-6
                                    flex
                                    justify-between
                                    "
                                    >

                                        <Link
                                            to="/shop"
                                            className="
                                        uppercase
                                        text-xs
                                        tracking-[0.3em]
                                        "
                                        >
                                            SHOP ALL
                                        </Link>





                                    </div>


                                </div>


                            </div>

                        )}

                    </div>




                    <Link
                        to="/contact"
                        className="text-sm hover:opacity-50"
                    >
                        Contact
                    </Link>


                </div>





                {/* RIGHT */}
                <div className="flex items-center gap-4">


                    <div className="
                    hidden
                    lg:block
                    w-[260px]
                    ">

                        <iframe
                            title="Spotify"
                            style={{borderRadius:"12px"}}
                            src="https://open.spotify.com/embed/album/0Hr4UiqidZHMMzCMTFXxzD?utm_source=generator"
                            width="100%"
                            height="80"
                            frameBorder="0"
                            loading="lazy"
                        />

                    </div>



                    <button className="hidden sm:block">
                        <Search className="w-5 h-5"/>
                    </button>



                    <AccountDropdown />



                    <Link
                        to="/cart"
                        className="relative"
                    >

                        <ShoppingBag className="w-5 h-5"/>


                        {itemCount > 0 && (

                            <span
                                className="
                            absolute
                            -top-2
                            -right-2
                            bg-black
                            text-white
                            text-[10px]
                            w-4
                            h-4
                            rounded-full
                            flex
                            items-center
                            justify-center
                            "
                            >

                                {itemCount}

                            </span>

                        )}

                    </Link>


                </div>


            </nav>



            <MobileNav
                isOpen={mobileNavOpen}
                onClose={()=>setMobileNavOpen(false)}
            />

        </>
    );
}


export default Navbar;